/* Automagically generated, do not edit! */
static const u_char t01_head1[] = ""
"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">"
"\n"
"<html xmlns=\"http://www.w3.org/1999/xhtml\">"
"\n"
"<head>"
"<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\"/>"
"<style type=\"text/css\">"
"body,html {background:#fff;font-family: \"Lucida Grande\",Calibri,Arial;font-size: 13pt;color: #333;background: #f8f8f8;}tr.e {background:#f4f4f4;}th,td {padding:0.1em 0.5em;}th {text-align:left;font-weight:bold;background:#eee;border-bottom:1px solid #aaa;}#top {width:80%;margin: 0 auto;padding: 0;}#top h1 {font-size: 20pt;margin:0;}#footer {width:80%;margin: 0 auto;padding: 10pt 0;font-size: 10pt;text-align:center;}#footer a {font-size: 9pt;font-weight: normal;text-decoration: underline;}#list {border:1px solid #aaa;width:80%;margin: 0 auto;padding: 0;}a {color: #b00;font-size: 11pt;font-weight: bold;text-decoration: none;}a:hover {color: #000;}#readme {padding:0;margin:1em 0;border:none;width:100%;}"
"</style>"
"\n"
;
static const u_char t02_head2[] = ""
"<title>MTimer 软件下载中心 By MTimer - 时光人系统"
;
static const u_char t03_head3[] = ""
"</title>"
"\n"
"</head>"
;
static const u_char t04_body1[] = ""
"<body>"
"<table id=\"top\" cellpadding=\"0\" cellspacing=\"1\">"
" <thead><tr><td colspan=\"2\">"
"<h1>MTimer 软件下载中心</h1>"
"软件下载目录"
;
static const u_char t05_body2[] = ""
"</td></tr></thead>"
;
static const u_char t06_list1[] = ""
"<table id=\"list\" cellpadding=\"0.1em\" cellspacing=\"0\">"
""
"\n"
"<colgroup>"
"<col width=\"55%\"/>"
"<col width=\"20%\"/>"
"<col width=\"25%\"/>"
"</colgroup>"
"\n"
"<thead>"
"<tr>"
"<th>文件名</th>"
"<th>文件大小</th>"
"<th>日期</th>"
"</tr>"
"</thead>"
"\n"
"<tbody>"
"<tr class=\"o\">"
"<td><a href=\"../\">上层目录/</a></td>"
"<td>-</td>"
"<td>-</td>"
"</tr>"
;
static const u_char t07_list2[] = ""
"</tbody>"
"</table>"
;
static const u_char t08_foot1[] = ""
"</body>"
"</html>"
;
#define NFI_TEMPLATE_SIZE (0 \
	+ nfi_sizeof_ssz(t05_body2) \
	+ nfi_sizeof_ssz(t06_list1) \
	+ nfi_sizeof_ssz(t07_list2) \
	+ nfi_sizeof_ssz(t08_foot1) \
	+ nfi_sizeof_ssz(t01_head1) \
	+ nfi_sizeof_ssz(t02_head2) \
	+ nfi_sizeof_ssz(t03_head3) \
	+ nfi_sizeof_ssz(t04_body1) \
	)
